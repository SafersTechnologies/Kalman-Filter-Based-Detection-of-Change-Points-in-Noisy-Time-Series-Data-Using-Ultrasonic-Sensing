import os
import serial
import csv
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from collections import deque

# =========================
# USER SETTINGS
# =========================
PORT = "COM9"          # change if needed
BAUD = 115200
MAX_POINTS = 150
ANIMATION_INTERVAL = 200   # ms

SAVE_PATH = r"C:\Users\adeko\Downloads"
CSV_FILENAME = "latest_distance.csv"
FULL_PATH = os.path.join(SAVE_PATH, CSV_FILENAME)

# =========================
# SERIAL SETUP
# =========================
ser = serial.Serial(PORT, BAUD, timeout=0.05)
ser.reset_input_buffer()

# =========================
# CSV SETUP
# =========================
os.makedirs(SAVE_PATH, exist_ok=True)
print("Saving CSV to:", FULL_PATH)

csv_file = open(FULL_PATH, mode="w", newline="", buffering=1)
csv_writer = csv.writer(csv_file)
csv_writer.writerow([
    "Sample",
    "Raw_mm",
    "Predicted_mm",
    "Filtered_mm",
    "Velocity_mm",
    "Residual_mm",
    "Drift_mm",
    "Change"
])

# =========================
# DATA BUFFERS
# =========================
x_data = deque(maxlen=MAX_POINTS)
raw_data = deque(maxlen=MAX_POINTS)
pred_data = deque(maxlen=MAX_POINTS)
filtered_data = deque(maxlen=MAX_POINTS)
velocity_data = deque(maxlen=MAX_POINTS)
residual_data = deque(maxlen=MAX_POINTS)
drift_data = deque(maxlen=MAX_POINTS)

change_x = deque(maxlen=MAX_POINTS)
change_y = deque(maxlen=MAX_POINTS)

sample_index = 0

# =========================
# PLOT SETUP
# =========================
fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(12, 10), sharex=True)

line_raw, = ax1.plot([], [], linewidth=1.0, marker="o", markersize=2,
                     label="Raw Distance (mm)", zorder=5)

line_pred, = ax1.plot([], [], linewidth=1.8, linestyle="--",
                      label="Predicted Distance (mm)", zorder=4)

line_filtered, = ax1.plot([], [], linewidth=2.0,
                          label="Filtered Distance (mm)", zorder=3)

scatter_change = ax1.scatter([], [], color="black", marker="x", s=70,
                             linewidths=2, label="Change Detected", zorder=7)

line_velocity, = ax2.plot([], [], linewidth=2, label="Velocity (mm/sample)")
line_residual, = ax3.plot([], [], linewidth=2, label="Residual (raw - pred)")
line_drift, = ax3.plot([], [], linewidth=2, linestyle="--", label="Drift (raw - filt)")

ax1.set_title("Real-Time 2D Kalman Distance Tracking")
ax1.set_ylabel("Distance (mm)")
ax1.legend()
ax1.grid(True)

ax2.set_title("Estimated Velocity")
ax2.set_ylabel("Velocity (mm/sample)")
ax2.legend()
ax2.grid(True)

ax3.set_title("Residual and Drift")
ax3.set_xlabel("Sample")
ax3.set_ylabel("Error (mm)")
ax3.legend()
ax3.grid(True)

value_text = fig.text(
    0.07, 0.97,
    "Raw: --   Pred: --   Filtered: --   Vel: --   Residual: --   Drift: --   Change: --",
    fontsize=10,
    bbox=dict(facecolor="white", alpha=0.9)
)

# =========================
# HELPERS
# =========================
def parse_change_flag(field: str) -> int:
    text = field.strip().upper()
    if text in {"1", "YES", "CHANGE DETECTED", "CHANGE"}:
        return 1
    return 0


def update_axes():
    if len(x_data) == 0:
        return

    xmin = max(0, sample_index - MAX_POINTS)
    xmax = sample_index + 1

    ax1.set_xlim(xmin, xmax)
    ax2.set_xlim(xmin, xmax)
    ax3.set_xlim(xmin, xmax)

    # Distance axis
    all_dist = list(raw_data) + list(pred_data) + list(filtered_data)
    y1_min = min(all_dist) - 15
    y1_max = max(all_dist) + 15
    if y1_min == y1_max:
        y1_min -= 1
        y1_max += 1
    ax1.set_ylim(y1_min, y1_max)

    # Velocity axis
    if len(velocity_data) > 0:
        y2_min = min(velocity_data) - 2
        y2_max = max(velocity_data) + 2
        if y2_min == y2_max:
            y2_min -= 1
            y2_max += 1
        ax2.set_ylim(y2_min, y2_max)

    # Residual/Drift axis
    all_err = list(residual_data) + list(drift_data)
    y3_min = min(all_err) - 2
    y3_max = max(all_err) + 2
    if y3_min == y3_max:
        y3_min -= 1
        y3_max += 1
    ax3.set_ylim(y3_min, y3_max)


# =========================
# ANIMATION UPDATE
# =========================
def update(frame):
    global sample_index
    latest_line = None

    try:
        # Drain buffer, keep latest complete line
        while ser.in_waiting:
            candidate = ser.readline().decode("utf-8", errors="ignore").strip()
            if candidate:
                latest_line = candidate

        if latest_line is None:
            return

        parts = [p.strip() for p in latest_line.split(",")]

        # Expected:
        # raw,predicted,filtered,velocity,residual,drift,status
        if len(parts) != 7:
            print("Skipped malformed line:", repr(latest_line))
            return

        raw = float(parts[0])
        pred = float(parts[1])
        filtered = float(parts[2])
        velocity = float(parts[3])
        residual = float(parts[4])
        drift = float(parts[5])
        change_flag = parse_change_flag(parts[6])

        # Save CSV
        csv_writer.writerow([
            sample_index,
            f"{raw:.2f}",
            f"{pred:.2f}",
            f"{filtered:.2f}",
            f"{velocity:.2f}",
            f"{residual:.4f}",
            f"{drift:.4f}",
            "YES" if change_flag else "NO"
        ])

        # Store data
        x_data.append(sample_index)
        raw_data.append(raw)
        pred_data.append(pred)
        filtered_data.append(filtered)
        velocity_data.append(velocity)
        residual_data.append(residual)
        drift_data.append(drift)

        if change_flag == 1:
            change_x.append(sample_index)
            change_y.append(raw + 5.0)

        # Update lines
        line_raw.set_data(x_data, raw_data)
        line_pred.set_data(x_data, pred_data)
        line_filtered.set_data(x_data, filtered_data)
        line_velocity.set_data(x_data, velocity_data)
        line_residual.set_data(x_data, residual_data)
        line_drift.set_data(x_data, drift_data)

        if len(change_x) > 0:
            scatter_change.set_offsets(np.column_stack((change_x, change_y)))
        else:
            scatter_change.set_offsets(np.empty((0, 2)))

        update_axes()

        value_text.set_text(
            f"Raw: {raw:.2f} mm   "
            f"Pred: {pred:.2f} mm   "
            f"Filtered: {filtered:.2f} mm   "
            f"Vel: {velocity:.2f} mm/sample   "
            f"Residual: {residual:.4f} mm   "
            f"Drift: {drift:.4f} mm   "
            f"Change: {'YES' if change_flag else 'NO'}"
        )

        sample_index += 1

    except Exception as e:
        print("Read error:", e)

# =========================
# RUN
# =========================
ani = FuncAnimation(fig, update, interval=ANIMATION_INTERVAL)

plt.tight_layout(rect=[0, 0, 1, 0.95])

try:
    plt.show()
finally:
    csv_file.close()
    ser.close()
    print("Serial port and CSV file closed.")