/*
 * ECE 513 Term Project, spring 2026
 * Created by Oluwaseun Adekola
 */

#include "launchpad.h"

// System tick clock frequency, which is the PIOSC in this library
#define SYSTICK_CLOCK_RATE 		16000000L

// maximum size for callback queue, see below
#define MAX_CALLBACK		    32

/***************************************************************************************
 * System time wait functions
 **************************************************************************************/

/*
 * Wait for a given number of microseconds
 */
void WaitUs(uint32_t timeUs)
{
    // Return immediately if timeMs is zero; otherwise, SysCtlDelay() would wait for a long time
    if (timeUs == 0)
        return;

    // Note: delayCount for SysCtlDelay() is three clock cycles
    uint32_t delay_count = (uint64_t) timeUs * CPU_CLOCK_RATE / 1000000;
    delay_count /= 3;
    SysCtlDelay(delay_count);
}

/*
 * Initialize Tiva C LaunchPad for ECE 266 labs
 */
void LaunchPadInit()
{
    /// Specifies a 50-MHz CPU clock with a PLL divider of 4, using the
    /// main OSC.
    // Note: The code is from the workshop workbook.
    // Guess: The base clock is 25MHz (default value), boosted by PLL to
    // 200MHz, and then divided by 4 to 50MHz (I checked the datasheet).
    // I am not sure about the last flag.
    SysCtlClockSet(
            SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN
                    | SYSCTL_XTAL_16MHZ);
    assert(SysCtlClockGet() == CPU_CLOCK_RATE);

    // Initialize the event-based scheduler
    EventSchedulerInit();

    // Initialize push button
    PushButtonInit();

    // Initialize the on-board LED
    LedInit();

    // Initialize UART0
    UartInit();
}
