# ECE531 Project Code Files

## Project Title

**Kalman Filter-Based Detection of Change Points in Noisy Time-Series Data Using Ultrasonic Sensing**

## Overview

This project implements a real-time embedded sensing system for detecting change points in noisy ultrasonic distance measurements. The system runs on a **Tiva C Series TM4C123G LaunchPad** and uses an **HC-SR04 ultrasonic sensor** to collect distance measurements. A velocity-aware two-state Kalman filter is used to estimate both distance and velocity, smooth noisy readings, predict system behavior, and detect sudden environmental changes.

The embedded system sends real-time UART data to a computer, where a Python script logs the data to a CSV file and visualizes raw distance, predicted distance, filtered distance, velocity, residual, drift, and detected change events.

## Main Features

- Real-time ultrasonic distance sensing.
- Two-state Kalman filter using position and velocity states.
- Prediction and correction-based distance estimation.
- Residual-based change detection.
- Temporal consistency check to reduce false detections.
- Seven-segment display output for filtered distance.
- LED and buzzer alert when a change is detected.
- UART output for real-time logging and analysis.
- Python-based live plotting and CSV data recording.

## Folder Structure

```text
ECE531_PROJECT_CODE_FILES/
│
├── ECE531_PROJECT/
│   ├── ECE513_main.c              # Main embedded application
│   ├── alert.c / alert.h          # LED and buzzer alert control
│   ├── ranger.c / ranger.h        # Ultrasonic ranger interface
│   ├── seg7.h                     # Seven-segment display interface
│   ├── seg7digit_sol.c            # Digit display conversion logic
│   ├── seg7raw.c                  # Raw seven-segment display driver
│   ├── tm4c123gh6pm.cmd           # Linker command file
│   ├── tm4c123gh6pm_startup_ccs.c # Startup file for CCS
│   ├── targetConfigs/             # Tiva target configuration
│   └── Debug/                     # CCS-generated build output
│
├── Util/
│   ├── event.c / event.h          # Event scheduler support
│   ├── launchpad.c / launchpad.h  # LaunchPad initialization utilities
│   ├── led.c                      # Onboard LED utility functions
│   ├── pushbutton.c               # Pushbutton support
│   ├── uart.c                     # UART communication support
│   └── Debug/                     # Utility library build output
│
└── plot.py                        # Python serial logger and live visualizer
```

## Hardware Requirements

- Tiva C Series TM4C123G LaunchPad.
- HC-SR04 ultrasonic distance sensor.
- Four-digit seven-segment display module.
- External buzzer.
- USB cable for programming and UART serial communication.
- Computer running Code Composer Studio and Python.

## Embedded System Description

The main embedded program is located in:

```text
ECE531_PROJECT/ECE513_main.c
```

The program performs the following real-time pipeline:

```text
Ultrasonic Sensing
        ↓
Distance Measurement
        ↓
Kalman Prediction
        ↓
Kalman Correction / Filtering
        ↓
Residual and Drift Computation
        ↓
Temporal Change Detection
        ↓
Seven-Segment Display, UART Logging, LED/Buzzer Alert
```

## Kalman Filter Model

The system uses a two-state Kalman filter:

```text
x = [position, velocity]^T
```

The filter estimates the current distance and velocity of change from ultrasonic measurements. The prediction stage estimates the next distance using the previous position and velocity, while the correction stage updates the estimate using the latest measured distance.

The main output values are:

- **Raw distance:** Direct ultrasonic distance measurement.
- **Predicted distance:** Distance predicted before measurement correction.
- **Filtered distance:** Corrected Kalman distance estimate.
- **Velocity:** Estimated rate of distance change.
- **Residual:** Difference between raw measurement and predicted distance.
- **Drift:** Difference between raw measurement and filtered distance.
- **Change status:** Indicates whether a significant change was detected.

## Important Parameters

The main configurable constants are defined in `ECE513_main.c`:

```c
#define SOUND_SPEED        340.0f
#define CLOCK_SPEED        50000000.0f
#define MAX_DIST_MM        5000
#define DETECT_THRESHOLD   5.0f
#define DETECT_COUNT_REQ   3
#define DT                 1.0f
#define MAX_VELOCITY_MM    50.0f
```

These parameters control the distance conversion, filtering behavior, detection threshold, number of consecutive detections required, time step, and maximum allowed velocity estimate.

## UART Output Format

The embedded system prints comma-separated UART data in the following format:

```text
raw,predicted,filtered,velocity,residual,drift,status
```

Example:

```text
584,583.81,583.85,-0.02,0.1900,0.1500,NO CHANGE
77,54.18,58.84,-36.68,22.8200,18.1600,CHANGE DETECTED
```

## Python Visualization Script

The Python visualization and logging script is:

```text
plot.py
```

It reads UART data from the microcontroller, saves the received data to a CSV file, and displays real-time plots for:

- Raw, predicted, and filtered distance.
- Estimated velocity.
- Residual and drift.
- Change detection markers.

## Python Requirements

Install the required Python packages before running `plot.py`:

```bash
pip install pyserial numpy matplotlib
```

## Running the Project

### 1. Open the Embedded Project

Open **Code Composer Studio (CCS)** and import the following projects:

```text
ECE531_PROJECT
Util
```

### 2. Build the Utility Library

Build the `Util` project first so that the support library is available.

### 3. Build and Flash the Main Project

Build and flash the `ECE531_PROJECT` project to the Tiva C TM4C123G LaunchPad.

### 4. Confirm Serial Port

In `plot.py`, confirm that the serial port matches the port assigned to the LaunchPad:

```python
PORT = "COM9"
BAUD = 115200
```

Change `COM9` if your computer assigns a different port.

### 5. Run the Python Logger

Run:

```bash
python plot.py
```

The script opens a live plot window and saves the output CSV file using the path defined in the script.

## CSV Output

The Python script saves the logged data with the following columns:

```text
Sample, Raw_mm, Predicted_mm, Filtered_mm, Velocity_mm, Residual_mm, Drift_mm, Change
```

This CSV file can be used later for offline analysis, plotting, report writing, and performance evaluation.

## Alert Behavior

When a change is detected:

- The onboard red LED turns on.
- The external buzzer pulses.
- The UART status field prints `CHANGE DETECTED`.
- The Python plot marks the event with a change indicator.

When no change is detected:

- The LED and buzzer remain off.
- The UART status field prints `NO CHANGE`.

## Notes
- The `Debug` folders contain generated build files from Code Composer Studio.
- The serial port and CSV save path in `plot.py` may need to be changed depending on the computer being used.
- The detection sensitivity can be adjusted by tuning `DETECT_THRESHOLD`, `DETECT_COUNT_REQ`, Kalman process noise `Q`, and measurement noise `R` in the embedded code.

## Project Summary

This project demonstrates how ultrasonic sensing, Kalman filtering, residual analysis, and embedded decision-making can be integrated into a practical real-time monitoring system. It is suitable for applications requiring low-cost distance monitoring, environmental change detection, object movement detection, and real-time embedded signal processing.
