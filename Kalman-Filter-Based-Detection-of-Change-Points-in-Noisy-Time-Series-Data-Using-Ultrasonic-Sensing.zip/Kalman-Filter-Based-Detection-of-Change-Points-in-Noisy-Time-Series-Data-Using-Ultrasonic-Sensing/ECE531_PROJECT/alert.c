/*
 * ECE 513 Term Project, spring 2026
 * Created by Oluwaseun Adekola
 */

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "alert.h"
#include "launchpad.h"

#define BUZZER_PORT   GPIO_PORTC_BASE
#define BUZZER_PIN    GPIO_PIN_5

void AlertInit(void)
{
    // Onboard red LED on PF1
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF));
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1);

    // External buzzer on PC5 (Grove J17)
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOC));
    GPIOPinTypeGPIOOutput(BUZZER_PORT, BUZZER_PIN);

    // Start with both OFF
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0);
    GPIOPinWrite(BUZZER_PORT, BUZZER_PIN, 0);
}

void UpdateAlert(bool change_detected)
{
    static int counter = 0;

    if (change_detected)
    {
        counter++;

        // LED stays ON during detection
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, GPIO_PIN_1);

        // Buzzer pulses instead of staying continuously ON
        if ((counter % 5) == 0)
        {
            GPIOPinWrite(BUZZER_PORT, BUZZER_PIN, BUZZER_PIN);
        }
        else
        {
            GPIOPinWrite(BUZZER_PORT, BUZZER_PIN, 0);
        }
    }
    else
    {
        counter = 0;

        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0);
        GPIOPinWrite(BUZZER_PORT, BUZZER_PIN, 0);
    }
}
void BeepTest(void)
{
    int i;
    for (i = 0; i < 5; i++)
    {
        GPIOPinWrite(BUZZER_PORT, BUZZER_PIN, BUZZER_PIN);
        WaitUs(200000);
        GPIOPinWrite(BUZZER_PORT, BUZZER_PIN, 0);
        WaitUs(200000);
    }
}
