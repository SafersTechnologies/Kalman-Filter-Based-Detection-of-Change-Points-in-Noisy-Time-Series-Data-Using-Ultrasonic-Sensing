#include "ranger.h"
typedef struct {
    Event *callback_event;
    enum {
        IDLE,
        EXPECT_START_EVENT_1,
        EXPECT_START_EVENT_2,
        EXPECT_DATA_EVENT_1,
        EXPECT_DATA_EVENT_2
    } state;
    bool new_data_ready;
    uint32_t start_time;       // rising-edge timestamp
    uint32_t measurement;      // pulse width in clock cycles
} RangerState;
volatile RangerState ranger;
void RangerISR();
void RangerInit()
{
    ranger.callback_event = NULL;
    ranger.new_data_ready = false;
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_WTIMER2);
    GPIOPinTypeTimer(GPIO_PORTD_BASE, GPIO_PIN_1);
    GPIOPinConfigure(GPIO_PD1_WT2CCP1);
    TimerControlLevel(WTIMER2_BASE, TIMER_B, true);
    TimerControlEvent(WTIMER2_BASE, TIMER_B, TIMER_EVENT_BOTH_EDGES);
    TimerIntRegister(WTIMER2_BASE, TIMER_B, RangerISR);
    TimerIntEnable(WTIMER2_BASE, TIMER_CAPB_EVENT);
}
void RangerTriggerReading()
{
    ranger.new_data_ready = false;
    ranger.state = EXPECT_START_EVENT_1;
    TimerDisable(WTIMER2_BASE, TIMER_B);
    TimerConfigure(WTIMER2_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_B_PWM);
    TimerLoadSet(WTIMER2_BASE, TIMER_B, 1000);
    TimerMatchSet(WTIMER2_BASE, TIMER_B, 500);
    TimerIntClear(WTIMER2_BASE, TIMER_CAPB_EVENT);
    TimerEnable(WTIMER2_BASE, TIMER_B);
}
bool RangerDataReady()
{
    return ranger.new_data_ready;
}
void RangerISR()
{
    switch (ranger.state)
    {
    case EXPECT_START_EVENT_1:
        TimerIntClear(WTIMER2_BASE, TIMER_CAPB_EVENT);
        ranger.state = EXPECT_START_EVENT_2;
        break;
    case EXPECT_START_EVENT_2:
        TimerDisable(WTIMER2_BASE, TIMER_B);
        TimerIntClear(WTIMER2_BASE, TIMER_CAPB_EVENT);
        TimerConfigure(WTIMER2_BASE,
            TIMER_CFG_SPLIT_PAIR | TIMER_CFG_B_CAP_TIME_UP);
        TimerLoadSet(WTIMER2_BASE, TIMER_B, 0xFFFFFFFF);
        TimerControlEvent(WTIMER2_BASE, TIMER_B, TIMER_EVENT_BOTH_EDGES);
        TimerControlLevel(WTIMER2_BASE, TIMER_B, true);
        TimerEnable(WTIMER2_BASE, TIMER_B);
        TimerIntEnable(WTIMER2_BASE, TIMER_CAPB_EVENT);
        ranger.state = EXPECT_DATA_EVENT_1;
        break;
    case EXPECT_DATA_EVENT_1:
        ranger.start_time = TimerValueGet(WTIMER2_BASE, TIMER_B);
        TimerIntClear(WTIMER2_BASE, TIMER_CAPB_EVENT);
        ranger.state = EXPECT_DATA_EVENT_2;
        break;
    case EXPECT_DATA_EVENT_2:
        ranger.measurement = TimerValueGet(WTIMER2_BASE, TIMER_B)
                             - ranger.start_time;
        ranger.new_data_ready = true;
        TimerIntClear(WTIMER2_BASE, TIMER_CAPB_EVENT);
        ranger.state = IDLE;
        break;
    default:
        TimerIntClear(WTIMER2_BASE, TIMER_CAPB_EVENT);
        ranger.state = IDLE;
        break;
    }
}
void RangerEventRegister(Event *event)
{
    ranger.callback_event = event;
}
uint32_t RangerGetData()
{
    return ranger.measurement;
}
