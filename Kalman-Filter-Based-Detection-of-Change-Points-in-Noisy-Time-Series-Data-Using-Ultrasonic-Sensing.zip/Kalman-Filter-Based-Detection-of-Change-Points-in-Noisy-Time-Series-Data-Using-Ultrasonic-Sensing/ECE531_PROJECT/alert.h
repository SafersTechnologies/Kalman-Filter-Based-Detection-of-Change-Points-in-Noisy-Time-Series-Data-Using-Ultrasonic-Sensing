/*
 * ECE 513 Term Project, spring 2026
 * Created by Oluwaseun Adekola
 */

#ifndef ALERT_H_
#define ALERT_H_

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "launchpad.h"

// Initialize the buzzer (PC5, Grove J17) and LED (PF1)
void AlertInit(void);

// Update alert state based on detection flag
void UpdateAlert(bool change_detected);

// Short beep test at startup to verify buzzer is working
void BeepTest(void);

#endif /* ALERT_H_ */
