/*
 * ECE 513 Term Project, spring 2026
 * Created by Oluwaseun Adekola
 */

#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include "launchpad.h"
#include "seg7.h"
#include "ranger.h"
#include "alert.h"

#define SOUND_SPEED        340.0f
#define CLOCK_SPEED        50000000.0f
#define MAX_DIST_MM        5000
#define DETECT_THRESHOLD   5.0f
#define DETECT_COUNT_REQ   3
#define DT                 1.0f
#define MAX_VELOCITY_MM    50.0f

typedef struct {
    uint16_t raw_dist_mm;
    float predicted_dist_mm;
    float filtered_dist_mm;
    float velocity_mm;
    float residual;           // Kalman residual: raw - prediction
    float residual_display;   // Drift: raw - filtered
    bool change_detected;
    bool new_sample_ready;
    bool kalman_initialized;
} SysState;

typedef struct {
    float x[2];      // [position, velocity]
    float P[2][2];   // covariance
    float Q[2][2];   // process noise
    float R;         // measurement noise
} KalmanFilter2D;

Event trigger_ranger_reading_event;

static SysState sys = {0, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false};
static KalmanFilter2D kf;

/*
 * Initialize 2D Kalman filter
 */
void KalmanInit(KalmanFilter2D *kf, float initial_pos, float initial_vel)
{
    kf->x[0] = initial_pos;
    kf->x[1] = initial_vel;

    kf->P[0][0] = 10.0f;
    kf->P[0][1] = 0.0f;
    kf->P[1][0] = 0.0f;
    kf->P[1][1] = 1.0f;

    kf->Q[0][0] = 0.05f;
    kf->Q[0][1] = 0.0f;
    kf->Q[1][0] = 0.0f;
    kf->Q[1][1] = 0.10f;

    kf->R = 150.0f;
}

/*
 * 2D Kalman filter update
 * Returns filtered estimate, and stores prediction, velocity, residual
 */
float KalmanUpdate(KalmanFilter2D *kf, float measurement,
                   float *prediction, float *velocity, float *residual)
{
    float x_pred[2];
    float P_pred[2][2];

    float p00 = kf->P[0][0];
    float p01 = kf->P[0][1];
    float p10 = kf->P[1][0];
    float p11 = kf->P[1][1];

    /* Prediction step */
    x_pred[0] = kf->x[0] + DT * kf->x[1];
    x_pred[1] = kf->x[1];

    /* Covariance prediction */
    P_pred[0][0] = p00 + DT * (p10 + p01) + DT * DT * p11 + kf->Q[0][0];
    P_pred[0][1] = p01 + DT * p11 + kf->Q[0][1];
    P_pred[1][0] = p10 + DT * p11 + kf->Q[1][0];
    P_pred[1][1] = p11 + kf->Q[1][1];

    *prediction = x_pred[0];
    *residual = measurement - x_pred[0];

    /* Update step */
    {
        float S = P_pred[0][0] + kf->R;
        float K0 = P_pred[0][0] / S;
        float K1 = P_pred[1][0] / S;

        kf->x[0] = x_pred[0] + K0 * (*residual);
        kf->x[1] = x_pred[1] + K1 * (*residual);

        if (kf->x[1] >  MAX_VELOCITY_MM) kf->x[1] =  MAX_VELOCITY_MM;
        if (kf->x[1] < -MAX_VELOCITY_MM) kf->x[1] = -MAX_VELOCITY_MM;

        kf->P[0][0] = (1.0f - K0) * P_pred[0][0];
        kf->P[0][1] = (1.0f - K0) * P_pred[0][1];
        kf->P[1][0] = P_pred[1][0] - K1 * P_pred[0][0];
        kf->P[1][1] = P_pred[1][1] - K1 * P_pred[0][1];
    }

    *velocity = kf->x[1];
    return kf->x[0];
}

/*
 * Trigger ultrasonic reading periodically
 */
void TriggerRangerReading(Event *event)
{
    RangerTriggerReading();
    EventSchedule(event, event->time + 500);
}

/*
 * Acquire and store the latest raw measurement
 */
void AcquireMeasurement(void)
{
    if (!RangerDataReady())
        return;

    uint32_t measurement = RangerGetData();

    if (measurement == 0)
        return;

    uint16_t distance_mm = (uint16_t)(((float)measurement / 2.0f)
                           * (SOUND_SPEED / CLOCK_SPEED) * 1000.0f);

    if (distance_mm > MAX_DIST_MM)
        return;

    sys.raw_dist_mm = distance_mm;
    sys.new_sample_ready = true;
}

/*
 * Process measurement through 2D Kalman filter
 */
void ProcessMeasurement(void)
{
    static int consecutive_count = 0;

    if (!sys.new_sample_ready)
        return;

    if (!sys.kalman_initialized) {
        KalmanInit(&kf, (float)sys.raw_dist_mm, 0.0f);
        sys.predicted_dist_mm = (float)sys.raw_dist_mm;
        sys.filtered_dist_mm = (float)sys.raw_dist_mm;
        sys.velocity_mm = 0.0f;
        sys.residual = 0.0f;
        sys.residual_display = 0.0f;
        sys.change_detected = false;
        sys.kalman_initialized = true;
        return;
    }

    sys.filtered_dist_mm = KalmanUpdate(&kf,
                                        (float)sys.raw_dist_mm,
                                        &sys.predicted_dist_mm,
                                        &sys.velocity_mm,
                                        &sys.residual);

    sys.residual_display = (float)sys.raw_dist_mm - sys.filtered_dist_mm;

    if (fabsf(sys.residual) > DETECT_THRESHOLD)
        consecutive_count++;
    else
        consecutive_count = 0;

    if (consecutive_count >= DETECT_COUNT_REQ)
        sys.change_detected = true;
    else
        sys.change_detected = false;
}

/*
 * Display filtered distance
 */
void UpdateDistanceDisplay(void)
{
    if (!sys.new_sample_ready)
        return;

    uint16_t display_mm = (uint16_t)(sys.filtered_dist_mm);

    Seg7Display seg7;

    seg7.digit[0] = display_mm % 10;
    seg7.digit[1] = (display_mm / 10) % 10;
    seg7.digit[2] = (display_mm / 100) % 10;
    seg7.digit[3] = (display_mm / 1000) % 10;

    if (display_mm < 1000) seg7.digit[3] = 0xFF;
    if (display_mm < 100)  seg7.digit[2] = 0xFF;
    if (display_mm < 10)   seg7.digit[1] = 0xFF;

    if (display_mm > 9999) {
        seg7.digit[0] = 9;
        seg7.digit[1] = 9;
        seg7.digit[2] = 9;
        seg7.digit[3] = 9;
    }

    seg7.colon_on = false;
    Seg7Update(&seg7);
}

/*
 * Print debug data to UART
 */
void PrintData(void)
{
    if (!sys.new_sample_ready)
        return;

    float predicted_print = roundf(sys.predicted_dist_mm * 100.0f) / 100.0f;
    float filtered_print = roundf(sys.filtered_dist_mm * 100.0f) / 100.0f;
    float velocity_print = roundf(sys.velocity_mm * 100.0f) / 100.0f;
    float drift_print = roundf(sys.residual_display * 10000.0f) / 10000.0f;

    uprintf("%u,%.2f,%.2f,%.2f,%.4f,%.4f,%s\r\n",
            sys.raw_dist_mm,
            predicted_print,
            filtered_print,
            velocity_print,
            sys.residual,
            drift_print,
            sys.change_detected ? "CHANGE DETECTED" : "NO CHANGE");

    sys.new_sample_ready = false;
}

/*
 * Main function
 */
void main(void)
{
    LaunchPadInit();
    RangerInit();
    Seg7Init();
    AlertInit();

    BeepTest();

    EventInit(&trigger_ranger_reading_event, TriggerRangerReading);
    EventSchedule(&trigger_ranger_reading_event, 100);

    while (true)
    {
        asm("   wfi");
        EventExecute();

        AcquireMeasurement();
        ProcessMeasurement();
        UpdateDistanceDisplay();
        UpdateAlert(sys.change_detected);
        PrintData();
    }
}
