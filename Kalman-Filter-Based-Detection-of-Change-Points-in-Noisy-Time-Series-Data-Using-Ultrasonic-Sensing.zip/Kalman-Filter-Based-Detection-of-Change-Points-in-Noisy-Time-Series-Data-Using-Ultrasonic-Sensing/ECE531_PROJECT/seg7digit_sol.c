/*
 * ECE 513 Term Project, spring 2026
 * Created by Oluwaseun Adekola
 */

#include <stdint.h>
#include <stdbool.h>
#include "seg7.h"

/*
 * 7-segment coding table. See https://en.wikipedia.org/wiki/Seven-segment_display. The segments
 * are named as A, B, C, D, E, F, G. In this coding table, segments A-G are mapped to bits 0-7.
 * Bit 7 is not used in the coding. This display uses active high signal, in which '1' turns ON a
 * segment, and '0' turns OFF a segment.
 *
 * Note: The table is incomplete. Fill the codes for digits 4-9.
 */
static uint8_t seg7_coding_table[10] = {
        0b00111111,         // digit 0
        0b00000110,         // digit 1
        0b01011011,         // digit 2
        0b01001111,         // digit 3
        
        0b01100110,         // digit 4
        0b01101101,         // digit 5
        0b01111101,         // digit 6
        0b00000111,         // digit 7
        0b01111111,         // digit 8
        0b01101111,         // digit 9
        0b00000000,
};

/*
 * Update the 7-segment display using the Seg7Display structure.
 */
void Seg7Update(Seg7Display *seg7)
{
    uint8_t seg7_code[4];
    uint8_t colon_code;
    int i;

    // Get the raw encoding for the colon
    colon_code = seg7->colon_on ? 0b10000000 : 0b00000000;

    //Encoding each digit (allowing 10 to mean blank)
    for(i = 0; i < 4; i++) {
        if (seg7->digit[i] <= 9){
            seg7_code[i] = seg7_coding_table[seg7->digit[i]] | colon_code;
        }
        else {
            seg7_code[i] = colon_code; //this is blank digit
        }
    }

    // Update the 7-segment
    Seg7RawUpdate(seg7_code);
}
